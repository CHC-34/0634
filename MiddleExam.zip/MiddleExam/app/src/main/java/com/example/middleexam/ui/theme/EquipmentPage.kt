package com.example.middleexam.ui.theme

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.painterResource


@Composable
fun EquipmentPage(navController:NavHostController){
    Column {
        Text(text = "装备信息")
        Inage(painter = painterResource(id = R.drawable),contentDescription = null)
        Text(text = "白色")
        Button(onClick = {
            navController.navigate("Home")
        }) {
            Text(text = "Home")
        }
    }
}