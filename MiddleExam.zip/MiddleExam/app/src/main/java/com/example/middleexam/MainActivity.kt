package com.example.middleexam

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.middleexam.ui.theme.MiddleExamTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MiddleExamTheme{

            }
        }
    }
}

fun Navigator() {
    val navController = rememberNavController()
    NavHost(navController = navcontroller, startDestination = "Home") {

        composable("Home") { HomePage(navController) }
        composable("CommodityPage") { Apage(navController) }
        composable("EquipmentPage ") { Bpage(navController) }
        composable("EndPage") { Cpage(navController) }
    }
}

@Composable
fun HomePage(navController: NavController) {
    Column {
        Button(onClick = {
            navController.navigate("CommodityPage")
        }) {
            Text(text = "CommodityPage")
        }

        Button(onClick = {
            navController.navigate("EquipmentPage ")
        }) {
            Text(text = "EquipmentPage")
        }
        Button(onClick = {
                navController.navigate("EndPage")
        }) {
            Text(text = "EndPage")
           }
        }
    }
@Composable
@Preview(showSystemUi = true)
    fun previHost() {
        Navigator()
    }


