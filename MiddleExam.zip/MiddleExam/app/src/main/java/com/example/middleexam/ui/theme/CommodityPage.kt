package com.example.middleexam.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.painterResource


@Composable
fun CommodityPage(navController:NavHostController){
    Column {
        Text(text = "商品信息")
        Image(painter = painterResource(id = R.drawable), contentDescription = null)
        Text(text = "颜色,白色")
        Button(onClick = { navController.navigate("Home") }) {
            Text(text = "home")
            
        }
    }
}