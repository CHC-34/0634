package com.example.middleexam.ui.theme

    data class Commodity(
        val id: Int,
        val name: String,
        val price: Double,
        val quantity: String,
        val description: Int
    )

    data class Equipment(
        val id: Int,
        val type: String,
        val model: String,
        val price: String,
        val description: Int
    )
    val commodityList = listOf(
        Commodity(1, "笔记本电脑", 3500.0, "轻薄便携，适合办公", 10),
        Commodity(2, "手机", 2500.0, "智能手机，配置高", 15),
        Commodity(3, "耳机", 200.0, "无线耳机，音质好", 20),
        Commodity(4, "书包", 150.0, "时尚书包，大容量", 30),
        Commodity(5, "水杯", 20.0, "保温水杯，多色可选", 50)
    )

    val equipmentList = listOf(
        Equipment(1, "电脑桌", "家具", "新品", 5),
        Equipment(2, "椅子", "家具", "良好", 10),
        Equipment(3, "投影仪", "电子设备", "良好", 3),
        Equipment(4, "键盘", "电子设备", "普通", 20),
        Equipment(5, "鼠标", "电子设备", "普通", 25)
    )
